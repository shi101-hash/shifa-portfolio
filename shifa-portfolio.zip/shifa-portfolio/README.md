# Shifa Siddiqui Portfolio

Interactive developer portfolio built using React, Tailwind CSS, and Framer Motion.