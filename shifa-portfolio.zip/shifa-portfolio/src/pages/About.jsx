const About = () => {
return (
<div className="max-w-4xl mx-auto px-4 py-16">
  <h2 className="text-3xl font-bold text-indigo-400 mb-4">About Me</h2>
  <p className="text-gray-300 mb-6">
    Passionate about Java programming, with a strong focus on software reliability. Skilled in Spring Boot and eager to enhance learning in modern technologies. Committed to writing clean, efficient code.
  </p>
  <h3 className="text-2xl font-semibold text-indigo-300 mb-2">Skills</h3>
  <ul className="grid grid-cols-2 md:grid-cols-3 gap-3 text-gray-200">
    <li>Java</li>
    <li>Spring Boot</li>
    <li>MongoDB</li>
    <li>HTML & CSS</li>
    <li>MySQL</li>
    <li>Git & GitHub</li>
    <li>Thymeleaf</li>
    <li>OOP & DBMS</li>
    <li>VS Code</li>
  </ul>
</div>
);
};

export default About;