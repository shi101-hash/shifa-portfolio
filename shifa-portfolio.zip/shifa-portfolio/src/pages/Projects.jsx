import ProjectCard from '../components/ProjectCard';

const Projects = () => {
const projects = [
{
title: 'Expense Tracker',
description: 'A web-based application for managing personal finances with login, budget categorization, and MongoDB integration.',
tech: 'Java, Spring Boot, Thymeleaf, MongoDB',
},
{
title: 'E-Voting System',
description: 'A secure and accessible web application for online voting to streamline the electoral process.',
tech: 'Java, Spring Boot, HTML/CSS, Thymeleaf, MVC',
},
{
title: 'TaskMaster',
description: 'A collaborative task management system with login, task assignment, and submission features.',
tech: 'Java, Spring Boot, MongoDB, Thymeleaf',
},
];

return (
<div className="max-w-6xl mx-auto px-4 py-16">
  <h2 className="text-3xl font-bold text-indigo-400 mb-8">Projects</h2>
  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
    {projects.map((proj, idx) => (
    <ProjectCard key={idx} {...proj} />
    ))}
  </div>
</div>
);
};

export default Projects;
