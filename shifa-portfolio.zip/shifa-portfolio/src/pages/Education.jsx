
// src/pages/Education.jsx
const Education = () => {
const education = [
{ degree: 'MCA', institution: 'CSM University, Mumbai', year: '2023–2025', gpa: 'CGPA: 8.79' },
{ degree: 'BSc-IT', institution: 'L.S. Raheja College, Mumbai', year: '2020–2023', gpa: 'CGPA: 8.77' },
{ degree: 'HSC', institution: 'Elia Sarwat College, Mumbai', year: '2018–2020' },
{ degree: 'SSC', institution: 'Sadhana Education Society, Mumbai', year: '2018' },
];

return (
<div className="max-w-4xl mx-auto px-4 py-16">
  <h2 className="text-3xl font-bold text-indigo-400 mb-8">Education</h2>
  <ul className="space-y-5">
    {education.map((edu, index) => (
    <li key={index} className="bg-gray-800 p-4 rounded-xl shadow">
      <h3 className="text-lg text-indigo-300 font-semibold">{edu.degree}</h3>
      <p className="text-gray-300">{edu.institution}</p>
      <p className="text-sm text-gray-400">{edu.year} {edu.gpa ? `| ${edu.gpa}` : ''}</p>
    </li>
    ))}
  </ul>
</div>
);
};

export default Education;
