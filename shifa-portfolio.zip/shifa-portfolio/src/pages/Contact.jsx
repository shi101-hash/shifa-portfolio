
// src/pages/Contact.jsx
const Contact = () => {
return (
<div className="max-w-xl mx-auto px-4 py-16 text-center">
  <h2 className="text-3xl font-bold text-indigo-400 mb-4">Contact Me</h2>
  <p className="text-gray-300 mb-6">Feel free to reach out through any platform below 👇</p>
  <div className="space-y-3">
    <p><a href="mailto:Siddiquishifa101@gmail.com" className="text-indigo-400 hover:underline">Siddiquishifa101@gmail.com</a></p>
    <p><a href="tel:+919372355141" className="text-indigo-400 hover:underline">+91-9372355141</a></p>
    <p><a href="https://linkedin.com/in/shifa-siddiqui-3a8597229" target="_blank" className="text-indigo-400 hover:underline">LinkedIn</a></p>
    <p><a href="https://github.com/shi101-hash" target="_blank" className="text-indigo-400 hover:underline">GitHub</a></p>
  </div>
</div>
);
};

export default Contact;
