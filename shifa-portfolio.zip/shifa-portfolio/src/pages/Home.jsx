import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const Home = () => {
  return (
    <motion.div
      className="flex flex-col items-center justify-center text-center py-24 px-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1 }}
    >
      <h1 className="text-4xl md:text-6xl font-bold text-indigo-400 mb-4">
        Hi, I'm Shifa Siddiqui
      </h1>
      <p className="text-gray-300 text-lg md:text-xl max-w-2xl mb-6">
        Java Developer passionate about building clean, efficient, and reliable software systems.
      </p>
      <div className="space-x-4">
        <Link
          to="/projects"
          className="bg-indigo-500 px-6 py-2 rounded-full text-white hover:bg-indigo-600 transition"
        >
          Projects
        </Link>
        <Link
          to="/contact"
          className="border border-indigo-400 px-6 py-2 rounded-full text-indigo-400 hover:bg-indigo-800 transition"
        >
          Contact Me
        </Link>
      </div>
    </motion.div>
  );
};

export default Home;
