
// src/pages/Experience.jsx
const Experience = () => {
const jobs = [
{
title: 'Web Developer - Digital Blue Ocean',
duration: 'Jan 2025 – Apr 2025',
description: 'Collaborated in website development using HTML, CSS, and Java. Participated in frontend/backend integration.',
},
{
title: 'Java Developer - VirtuNexa Internship',
duration: 'Jan 2025 – Feb 2025',
description: 'Worked on Java-based backend modules. Assisted in Agile team operations and sprint planning.',
},
];

return (
<div className="max-w-4xl mx-auto px-4 py-16">
  <h2 className="text-3xl font-bold text-indigo-400 mb-8">Professional Experience</h2>
  <ul className="space-y-6">
    {jobs.map((job, index) => (
    <li key={index} className="bg-gray-800 p-4 rounded-xl shadow-md">
      <h3 className="text-xl font-semibold text-indigo-300">{job.title}</h3>
      <p className="text-sm text-gray-400 mb-2">{job.duration}</p>
      <p className="text-gray-300">{job.description}</p>
    </li>
    ))}
  </ul>
</div>
);
};

export default Experience;
