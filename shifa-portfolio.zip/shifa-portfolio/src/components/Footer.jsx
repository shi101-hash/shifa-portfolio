const Footer = () => {
  return (
    <footer className="bg-gray-900 text-center py-6 text-sm text-gray-400">
      <p>© 2025 Shifa Siddiqui. Made with 💻 using React & Tailwind CSS.</p>
    </footer>
  );
};

export default Footer;
