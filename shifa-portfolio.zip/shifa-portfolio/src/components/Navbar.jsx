import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav className="bg-gray-900 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 py-3 flex justify-between items-center">
        <h1 className="text-2xl font-bold text-indigo-400">Shifa Siddiqui</h1>
        <ul className="flex space-x-6 text-white">
          <li><Link to="/" className="hover:text-indigo-400">Home</Link></li>
          <li><Link to="/about" className="hover:text-indigo-400">About</Link></li>
          <li><Link to="/projects" className="hover:text-indigo-400">Projects</Link></li>
          <li><Link to="/experience" className="hover:text-indigo-400">Experience</Link></li>
          <li><Link to="/education" className="hover:text-indigo-400">Education</Link></li>
          <li><Link to="/contact" className="hover:text-indigo-400">Contact</Link></li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
