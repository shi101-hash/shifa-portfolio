const ProjectCard = ({ title, description, tech, link }) => {
  return (
    <div className="bg-gray-800 p-6 rounded-2xl shadow-md hover:shadow-xl transition-shadow">
      <h3 className="text-xl font-semibold text-indigo-300 mb-2">{title}</h3>
      <p className="text-gray-300 mb-3">{description}</p>
      <p className="text-sm text-gray-400 mb-3">Tech Used: {tech}</p>
      {link && (
        <a href={link} target="_blank" rel="noopener noreferrer" className="text-indigo-400 hover:underline">
          View Project
        </a>
      )}
    </div>
  );
};

export default ProjectCard;
